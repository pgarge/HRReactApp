export type GetTokenFn = () => string | undefined;
