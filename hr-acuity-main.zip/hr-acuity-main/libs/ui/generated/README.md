# ui-generated

Generated types based on the OpenAPI decorators in the API project. Big fan of having
the backend be the source of truth for the API contracts whenever possible.
