/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type { CreateMessage } from './models/CreateMessage';
export type { Login } from './models/Login';
export type { Message } from './models/Message';
export type { UpdateMessage } from './models/UpdateMessage';
export type { User } from './models/User';
