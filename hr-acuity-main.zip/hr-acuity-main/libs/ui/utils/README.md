# ui-utils

Utilities and helpers, yes this is all overkill for this project, but trying to give a
nod to how I'd abstract things out IRL.

## Running unit tests

Run `nx test ui-utils` to execute the unit tests via [Jest](https://jestjs.io).
