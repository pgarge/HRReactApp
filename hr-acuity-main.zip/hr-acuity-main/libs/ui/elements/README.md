# elements

A library for low-level atoms and other design-system pieces. In this case it will only
have a textarea because I cannot believe MUI doesn't ship with one.

## Running unit tests

Run `nx test elements` to execute the unit tests via [Jest](https://jestjs.io).
